<?php /* Smarty version 3.1.26, created on 2019-06-23 06:54:02
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
         compiled from "templates/success.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:542618895d0f220abd5657_17149588%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '103126891ba927f98e721043c3e972a7bddc12a9' => 
    array (
      0 => 'templates/success.tpl',
      1 => 1561207708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '542618895d0f220abd5657_17149588',
  'has_nocache_code' => false,
  'version' => '3.1.26',
  'unifunc' => 'content_5d0f220abdd507_23423788',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d0f220abdd507_23423788')) {
function content_5d0f220abdd507_23423788 ($_smarty_tpl) {
$_smarty_tpl->properties['nocache_hash'] = '542618895d0f220abd5657_17149588';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="favicon.ico">
		<title>星球管理系统</title>
		<!-- Bootstrap core CSS -->
		<link href="./public/css/bootstrap.min.css" rel="stylesheet">
		<?php echo '<script'; ?>
 src="./public/js/jquery.min.js"><?php echo '</script'; ?>
>
        <style>
body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
  text-align:center;
}
</style>
	</head>
	<body>
	<div style="margin:0 auto;width:50%" class="alert alert-success">
	  <button type="button" class="close" data-dismiss="alert"></button>
	  <strong>successful!</strong>your oprating is ok！
	</div>
	</body>
</html><?php }
}
?>