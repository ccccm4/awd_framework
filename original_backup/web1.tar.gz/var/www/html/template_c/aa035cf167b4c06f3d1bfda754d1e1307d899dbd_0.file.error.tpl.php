<?php /* Smarty version 3.1.26, created on 2019-06-23 06:34:12
         compiled from "templates/error.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14239283745d0f1d642e4025_30836598%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa035cf167b4c06f3d1bfda754d1e1307d899dbd' => 
    array (
      0 => 'templates/error.tpl',
      1 => 1561207708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14239283745d0f1d642e4025_30836598',
  'has_nocache_code' => false,
  'version' => '3.1.26',
  'unifunc' => 'content_5d0f1d642ebf11_91416815',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d0f1d642ebf11_91416815')) {
function content_5d0f1d642ebf11_91416815 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '14239283745d0f1d642e4025_30836598';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="favicon.ico">
		<title>星球管理系统</title>
		<!-- Bootstrap core CSS -->

		<link href="./public/css/bootstrap.min.css" rel="stylesheet">
		<?php echo '<script'; ?>
 src="./public/js/jquery.min.js"><?php echo '</script'; ?>
>
        <style>
body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
    text-align:center;
}

</style>
	</head>
	<body>
	<div style="margin:0 auto;width:50%" class="alert alert-warning">
  <button type="button" class="close" data-dismiss="alert"></button>
  <strong>Warning!</strong> Something wrong，check again！
</div>
	</body>
</html><?php }
}
?>