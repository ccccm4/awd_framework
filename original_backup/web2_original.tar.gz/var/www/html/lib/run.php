<?php
@include_once("/var/www/html/include/waf.php");
    include "./base.php";
?>