<?php
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
    include "./base.php";
?>